alert('Bem vindo ao jogo do numero secreto')
let numeroSecreto = parseInt( Math.randon() * 100 + 1);
console.log(numeroSecreto);
let chute 
let tentativas = 1;

while (chute != numeroSecreto){
    chute = prompt("Digite seu número de 1 a 100");


    alert
if (chute == numeroSecreto){
    break;(`Você acertou! O numero secreto é ${numeroSecreto} com total de ${tentativas} tentativas`);
    } else{
            if (chute > numeroSecreto){
                alert(`O número secreto é menor que ${chute}`)
            } else {
                alert(`O número secreto é maior que ${chute}`)
            }

        }
    tentativas++;
}   

let PalavraTentativas = tentativa > 1 ? "tentativas" : "tentativa";
alert;(`Você acertou! O numero secreto é ${numeroSecreto} com total de ${PalavraTentativa}`);

//if (tentativas > 1 ){
    // alert;(`Você acertou! O numero secreto é ${numeroSecreto} com total de ${tentativas} tentativas`);
// } else {
   //  alert;(`Você acertou! O numero secreto é ${numeroSecreto} com total de ${tentativas} tentativa`);
//}





